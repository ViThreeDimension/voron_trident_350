Pin mod for the Voron Trident based on Hartk V2 work.

Need to print all gantry parts that has Idlers
- AB drive frames
- XY Joints
- Front Tensioners

Files

BOM
[A-B] 
threaded(or not) @  30mm (x2)
smooth   @  28mm (x2)

[X-Y Joints]
smooth   @  40mm (x4)

[X-Y Idlers]
smooth   @  43mm (x2)

Smooth pins

https://www.aliexpress.com/item/1739093502.html

threaded pins

https://www.ebay.com/itm/%CF%865mm-%CF%8612mm-Female-Thread-Cylindrical-Pin-Dowel-Pins-A2-304-Stainless-Steel/184373551069

Misumi Part Numbers
Part NO. 	Qty
SFRT5-30-M3 	2
SFR5-43 	2
SFR5-40 	4
SFR5-28 	2